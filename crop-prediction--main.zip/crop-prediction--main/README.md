# crop-prediction-
"Our crop prediction project combines HTML, JavaScript, CSS, and Python to offer a user-friendly interface for predicting optimal crops based on temperature and humidity inputs. The frontend, styled with CSS and structured using HTML, presents input fields for temperature and humidity values. 
